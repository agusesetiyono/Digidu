
      </div>
    </div>

    <footer id="footer">
      <div class="container">
        <p class="text-muted credit">&copy; <?php echo date('Y'); ?> <?php if(isset($site_name)) echo $site_name; ?></p>
      </div>
    </footer>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>

    <script src="<?php echo base_url(); ?>/assets/js/javascript.js"></script>
</body>
 </html>