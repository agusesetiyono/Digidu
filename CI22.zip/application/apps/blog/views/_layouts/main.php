<?php $this->load->view('_blocks/header'); ?>
<?php $this->load->view($view_file); ?>
<?php $this->load->view('_blocks/footer'); ?>